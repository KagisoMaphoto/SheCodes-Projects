// JS Challenge 2: Save your OpenWeatherMap API key here
let apiKey = "YOUR_API_KEY"; // 🔁 Replace with your actual key

// JS Challenge 3: Build the API URL for weather in Sydney (metric units)
let apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=Sydney&units=metric&appid=${apiKey}`;

// Make the API request using Axios
axios.get(apiUrl).then(function (response) {
  // JS Challenge 4: Log the current temperature in Sydney
  let temperature = response.data.main.temp;
  console.log(`Current temperature in Sydney: ${temperature}°C`);

  // JS Challenge 5: Replace the <h1> with the temperature message
  let heading = document.querySelector("h1");
  heading.innerHTML = `It is ${Math.round(temperature)} degrees in Sydney`;
});
